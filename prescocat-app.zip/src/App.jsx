import React, { useMemo, useState, useEffect } from "react";

function hasClipboard() {
  return typeof navigator !== "undefined" && navigator.clipboard && navigator.clipboard.writeText;
}

async function safeShare({ title, text }) {
  if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
    try {
      await navigator.share({ title, text });
      return { method: "share", ok: true };
    } catch (err) {}
  }
  if (hasClipboard()) {
    try {
      await navigator.clipboard.writeText(text);
      return { method: "clipboard", ok: true };
    } catch (err) {}
  }
  try {
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "prescocat_respuestas.txt";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    return { method: "download", ok: true };
  } catch (err) {
    return { method: "none", ok: false, error: err };
  }
}

const BREEDS = [
  { id: "ragdoll", name: "Ragdoll", tags: ["muy dócil", "súper cariñoso", "bajo nivel de actividad"], attributes: { affection: 5, activity: 2, grooming: 2, kidFriendly: 5, spaceNeed: 2, hypoallergenic: 0, price: 4, temperament: "dulce" }, blurb: "Gato mimoso, tranquilo y súper familiar. Ideal si buscas calma y compañía constante." },
  { id: "siberiano", name: "Siberiano", tags: ["hipoalergénico", "juguetón", "equilibrado"], attributes: { affection: 4, activity: 3, grooming: 3, kidFriendly: 5, spaceNeed: 3, hypoallergenic: 1, price: 5, temperament: "equilibrado" }, blurb: "Excelente para alérgicos leves a moderados. Sociable, activo sin ser hiperactivo." },
  { id: "mainecoon", name: "Maine Coon", tags: ["gran tamaño", "sociable", "juguetón"], attributes: { affection: 4, activity: 4, grooming: 3, kidFriendly: 5, spaceNeed: 5, hypoallergenic: 0, price: 5, temperament: "amigable" }, blurb: "Gigante gentil, muy paciente con niños. Requiere más espacio y presupuesto." },
  { id: "persa", name: "Persa", tags: ["muy tranquilo", "alto grooming"], attributes: { affection: 4, activity: 1, grooming: 5, kidFriendly: 4, spaceNeed: 2, hypoallergenic: 0, price: 4, temperament: "sereno" }, blurb: "Temperamento calmado; necesita cepillado frecuente. Perfecto para hogares serenos." },
  { id: "angora", name: "Angora Turco", tags: ["activo", "inteligente"], attributes: { affection: 4, activity: 4, grooming: 3, kidFriendly: 4, spaceNeed: 3, hypoallergenic: 0, price: 3, temperament: "vivaz" }, blurb: "Elegante y despierto, disfruta juego y estimulación mental. Buen equilibrio general." },
  { id: "ragamuffin", name: "Ragamuffin", tags: ["muy cariñoso", "fácil de manejar"], attributes: { affection: 5, activity: 2, grooming: 2, kidFriendly: 5, spaceNeed: 2, hypoallergenic: 0, price: 4, temperament: "afable" }, blurb: "Súper afectuoso, adaptable y dócil. Gran compañero para familias con niños." },
];

const initialForm = {
  emotionalSupport: 3,
  personality: "equilibrado",
  timeAvailable: 3,
  budget: "medio",
  space: "medio",
  temperament: "afectuoso",
  allergy: "ninguna",
  petPreference: "compania",
};

const BUDGET_MAP = { bajo: 1, medio: 3, alto: 5 };
const SPACE_MAP = { poco: 1, medio: 3, amplio: 5 };

function scoreBreed(form, breed) {
  const a = breed.attributes;
  let score = 0;
  let reasons = [];

  score += a.affection * form.emotionalSupport;
  if (a.affection >= 4 && form.emotionalSupport >= 4) reasons.push("alto afecto para soporte emocional");

  if (form.personality === "muy_tranquilo") {
    score += (6 - a.activity) * 2;
    if (a.activity <= 2) reasons.push("personalidad tranquila");
  } else if (form.personality === "muy_activo") {
    score += a.activity * 2;
    if (a.activity >= 4) reasons.push("energía y juego");
  } else {
    score += (5 - Math.abs(3 - a.activity)) * 1.5;
  }

  const timeFactor = form.timeAvailable;
  score += Math.max(0, 6 - a.grooming) * timeFactor;
  if (timeFactor <= 2 && a.grooming <= 2) reasons.push("bajo mantenimiento");
  if (timeFactor >= 4 && a.grooming >= 4) reasons.push("dispuesto a grooming alto");

  const budgetNum = BUDGET_MAP[form.budget] || 3;
  score += Math.max(0, 6 - Math.abs(budgetNum - a.price) * 1.5) * 2;
  if (budgetNum >= 4 && a.price >= 4) reasons.push("presupuesto adecuado");
  if (budgetNum <= 2 && a.price <= 3) reasons.push("ajusta a presupuesto moderado");

  const spaceNum = SPACE_MAP[form.space] || 3;
  score += Math.max(0, 6 - Math.abs(spaceNum - a.spaceNeed) * 1.5) * 2;
  if (spaceNum <= 2 && a.spaceNeed <= 2) reasons.push("se adapta a espacios reducidos");
  if (spaceNum >= 4 && a.spaceNeed >= 4) reasons.push("aprovecha espacios amplios");

  if (form.temperament === "afectuoso" && ["dulce", "afable"].includes(a.temperament)) score += 4;
  if (form.temperament === "independiente" && a.activity >= 3) score += 3;
  if (form.temperament === "jugueton" && a.activity >= 4) score += 4;

  if (form.allergy !== "ninguna") {
    score += a.hypoallergenic ? 8 : -6;
    if (a.hypoallergenic) reasons.push("apto para alergias");
  }

  if (form.petPreference === "compania") score += (6 - a.activity) + a.affection;
  if (form.petPreference === "juego") score += a.activity * 2;
  if (form.petPreference === "equilibrado") score += (a.activity >= 3 ? 2 : 1) + (a.affection >= 4 ? 2 : 1);

  const normalized = Math.max(0, Math.min(100, Math.round((score / 60) * 100)));
  return { score: normalized, reasons };
}

function useLocalForm() {
  const [form, setForm] = useState(() => {
    try {
      const saved = localStorage.getItem("prescocat_form");
      return saved ? JSON.parse(saved) : initialForm;
    } catch {
      return initialForm;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem("prescocat_form", JSON.stringify(form));
    } catch {}
  }, [form]);
  return [form, setForm];
}

function Field({ label, children, help }) {
  return (
    <div className="mb-5">
      <div className="flex items-baseline justify-between">
        <label className="font-medium text-slate-800">{label}</label>
        {help && <span className="text-xs text-slate-500">{help}</span>}
      </div>
      <div className="mt-2">{children}</div>
    </div>
  );
}

function Pill({ children }) {
  return (
    <span className="text-xs px-2 py-1 rounded-full bg-slate-100 border border-slate-200 mr-2 mb-2 inline-block">
      {children}
    </span>
  );
}

export default function PrescocatAdvisorApp() {
  const [form, setForm] = useLocalForm();

  const results = useMemo(() => {
    return BREEDS.map((b) => ({
      breed: b,
      ...scoreBreed(form, b),
    }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);
  }, [form]);

  const handleNumber = (k) => (e) => setForm({ ...form, [k]: Number(e.target.value) });
  const handleString = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <div className="min-h-screen bg-gradient-to-b from-rose-50 to-white text-slate-900">
      <header className="max-w-6xl mx-auto px-5 pt-10 pb-6">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">Prescocat · Asesor de Raza</h1>
            <p className="text-slate-600 mt-1">Toma decisiones informadas para tu familia según tiempo, presupuesto, espacio, temperamento y más.</p>
          </div>
          <a
            href="https://wa.me/573000000000?text=Hola%20Prescocat%2C%20quiero%20asesor%C3%ADa%20para%20elegir%20mi%20gatito"
            className="inline-flex items-center justify-center rounded-2xl px-4 py-2 bg-rose-600 text-white shadow hover:bg-rose-700 transition"
          >
            WhatsApp Prescocat
          </a>
        </div>
      </header>

      <main className="max-w-6xl mx-auto grid md:grid-cols-2 gap-6 px-5 pb-16">
        {/* Formulario */}
        <section className="bg-white rounded-2xl shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Cuestionario familiar</h2>

          <Field label={`Necesito soporte emocional (${form.emotionalSupport}/5)`} help="1 = poco, 5 = mucho">
            <input type="range" min={1} max={5} value={form.emotionalSupport} onChange={handleNumber("emotionalSupport")} className="w-full" />
          </Field>

          <Field label="Personalidad buscada">
            <select value={form.personality} onChange={handleString("personality")} className="w-full rounded-xl border p-2">
              <option value="equilibrado">Equilibrado</option>
              <option value="muy_tranquilo">Muy tranquilo</option>
              <option value="muy_activo">Muy activo</option>
            </select>
          </Field>

          <Field label={`Tiempo disponible para cuidado (${form.timeAvailable}/5)`} help="Incluye juego, limpieza y cepillado">
            <input type="range" min={1} max={5} value={form.timeAvailable} onChange={handleNumber("timeAvailable")} className="w-full" />
          </Field>

          <Field label="Poder adquisitivo (presupuesto)">
            <select value={form.budget} onChange={handleString("budget")} className="w-full rounded-xl border p-2">
              <option value="bajo">Bajo</option>
              <option value="medio">Medio</option>
              <option value="alto">Alto</option>
            </select>
          </Field>

          <Field label="Espacio disponible en casa">
            <select value={form.space} onChange={handleString("space")} className="w-full rounded-xl border p-2">
              <option value="poco">Poco</option>
              <option value="medio">Medio</option>
              <option value="amplio">Amplio</option>
            </select>
          </Field>

          <Field label="Temperamento deseado">
            <select value={form.temperament} onChange={handleString("temperament")} className="w-full rounded-xl border p-2">
              <option value="afectuoso">Afectuoso</option>
              <option value="independiente">Más independiente</option>
              <option value="jugueton">Muy juguetón</option>
            </select>
          </Field>

          <Field label="Alergias en el hogar">
            <select value={form.allergy} onChange={handleString("allergy")} className="w-full rounded-xl border p-2">
              <option value="ninguna">Ninguna</option>
              <option value="leve">Leve</option>
              <option value="moderada">Moderada</option>
            </select>
          </Field>

          <Field label="¿Qué buscas principalmente en tu mascota?">
            <select value={form.petPreference} onChange={handleString("petPreference")} className="w-full rounded-xl border p-2">
              <option value="compania">Compañía y calma</option>
              <option value="juego">Juego y actividad</option>
              <option value="equilibrado">Equilibrio</option>
            </select>
          </Field>

          <div className="flex gap-3 pt-2">
            <button
              onClick={() => {
                localStorage.removeItem("prescocat_form");
                window.location.reload();
              }}
              className="rounded-2xl border px-4 py-2 hover:bg-slate-50"
            >
              Reiniciar
            </button>
            <button
              onClick={async () => {
                const res = await safeShare({ title: "Mi asesor Prescocat", text: JSON.stringify(form, null, 2) });
                if (res.ok && res.method === "clipboard") alert("Respuestas copiadas al portapapeles ✅");
                if (res.ok && res.method === "download") alert("Archivo descargado con tus respuestas ✅");
                if (!res.ok) alert("No fue posible compartir. Intenta manualmente copiar el texto.");
              }}
              className="rounded-2xl border px-4 py-2 hover:bg-slate-50"
            >
              Compartir respuestas
            </button>
          </div>
        </section>

        {/* Resultados */}
        <section className="bg-white rounded-2xl shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Recomendación personalizada</h2>

          <ul className="space-y-4">
            {results.map(({ breed, score, reasons }) => (
              <li key={breed.id} className="border rounded-2xl p-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-lg font-semibold">{breed.name}</h3>
                    <p className="text-slate-600 text-sm mt-1">{breed.blurb}</p>
                    <div className="mt-2">
                      {breed.tags.map((t) => (
                        <Pill key={t}>{t}</Pill>
                      ))}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold">{score}</div>
                    <div className="text-xs text-slate-500">/100</div>
                  </div>
                </div>
                {reasons.length > 0 && (
                  <div className="mt-3 text-sm">
                    <div className="font-medium">Coincidencias clave:</div>
                    <ul className="list-disc ml-5 text-slate-600">
                      {reasons.slice(0, 3).map((r, i) => (
                        <li key={i}>{r}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="mt-4 flex flex-wrap gap-3">
                  <a
                    className="rounded-2xl px-4 py-2 bg-rose-600 text-white hover:bg-rose-700"
                    href={`https://wa.me/573000000000?text=Hola%20Prescocat%2C%20quiero%20conocer%20gatitos%20${encodeURIComponent(
                      breed.name
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Agendar visita
                  </a>
                  <button className="rounded-2xl px-4 py-2 border hover:bg-slate-50">
                    Ver disponibles
                  </button>
                </div>
              </li>
            ))}
          </ul>

          <div className="mt-6 p-4 bg-rose-50 rounded-xl text-sm text-slate-700">
            <div className="font-semibold mb-1">Cómo calculamos la recomendación</div>
            Se ponderan: soporte emocional, personalidad, tiempo vs grooming, presupuesto, espacio, temperamento, alergias y preferencia principal. El puntaje está normalizado a 0–100.
          </div>
        </section>
      </main>

      <footer className="max-w-6xl mx-auto px-5 pb-10 text-xs text-slate-500">
        © {new Date().getFullYear()} Prescocat · Prototipo de asesor virtual para familias.
      </footer>
    </div>
  );
}